import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

import Nav from './components/Nav';

const App = () => {
  return (
    <Nav/>
  );
}
 
export default App;